names = ['Bob', 'Sue', 'Amanda']
grade_point_averages = [3.5, 4.0, 3.75]
for name, gpa in zip(names, grade_point_averages):
    print(f'Name={name}; GPA={gpa}')


#list comprehension and zip

names = ['Ali', 'Sara', 'Faysal', 'Farah']
scores = [80, 65, 90, 75]
threshold = 70

below_threshold = [(name, score) for name, score in zip(names, scores) if score < threshold]
print(below_threshold)
for name, score in below_threshold:
    print(f'{name}: {score}')


