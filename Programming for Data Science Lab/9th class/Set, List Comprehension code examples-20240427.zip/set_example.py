colors = {'red', 'orange', 'yellow', 'green',1,(1,2,3) }
print(colors)
print(len(colors))


print('red' in colors)
print('violet' not in colors)
""" for c in colors:
    print(c.upper(), end=' ')
 """



#creating set from a list
numbers = list(range(10)) + list(range(5))
print()
print(numbers)
s = set(numbers)
print(s)

